export const SUPPORTED_CHAINS = ["hardhat"];

export const WALLETCONNECT_PROJECT_ID = "YOUR_PROJECT_ID";
