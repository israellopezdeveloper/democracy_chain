import json
import shutil

import pika
from fastapi import FastAPI, File, Form, UploadFile

app = FastAPI()
QUEUE_NAME = "documents"

connection = pika.BlockingConnection(pika.ConnectionParameters("rabbitmq"))
channel = connection.channel()
channel.queue_declare(queue=QUEUE_NAME)


@app.post("/upload/")
async def upload_document(file: UploadFile = File(...), program_id: str = Form(...)):
    path = f"/data/{file.filename}"
    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    message = {
        "filepath": path,
        "filename": file.filename,
        "program_id": program_id,
    }

    channel.basic_publish(
        exchange="",
        routing_key=QUEUE_NAME,
        body=json.dumps(message),
    )
    return {
        "message": "Document received",
        "file": file.filename,
        "program_id": program_id,
    }
